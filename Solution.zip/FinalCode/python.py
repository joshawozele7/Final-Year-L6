import tkinter as tk
from tkinter import messagebox, ttk
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

# Load all datasets
file_paths = {
    "circuits": "circuits.csv",
    "constructor_results": "constructor_results.csv",
    "constructor_standings": "constructor_standings.csv",
    "constructors": "constructors.csv",
    "driver_standings": "driver_standings.csv",
    "drivers": "drivers.csv",
    "lap_times": "lap_times.csv",
    "pit_stops": "pit_stops.csv",
    "qualifying": "qualifying.csv",
    "races": "races.csv",
    "results": "results.csv",
    "seasons": "seasons.csv",
    "sprint_results": "sprint_results.csv",
    "status": "status.csv",
}

dataframes = {}

# Function to load data
def load_data():
    global dataframes
    messagebox.showinfo("Loading Data", "Data loading process started.")
    for name, path in file_paths.items():
        try:
            dataframes[name] = pd.read_csv(path)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load {name}: {e}")
    messagebox.showinfo("Loading Data", "Data loading process completed.")

def validate_columns():
    messagebox.showinfo("Validation", "Column validation process started.")
    errors = []
    required_columns = {
        "races": ["raceId", "year", "name"],
        "constructors": ["constructorId", "name"],
        "results": ["resultId", "raceId", "driverId", "constructorId", "position", "points"],
    }
    
    for dataset, columns in required_columns.items():
        if dataset in dataframes:
            missing_columns = [col for col in columns if col not in dataframes[dataset].columns]
            if missing_columns:
                errors.append(f"{dataset} is missing columns: {missing_columns}")
        else:
            errors.append(f"{dataset} is not loaded.")
    
    if errors:
        messagebox.showerror("Validation Errors", "\n".join(errors))
        return False
    messagebox.showinfo("Validation", "Column validation process completed.")
    return True

# Function to preprocess data with dynamic column handling
def preprocess_data():
    messagebox.showinfo("Preprocessing", "Data preprocessing process started.")
    try:
        drivers = dataframes["drivers"]
        races = dataframes["races"]
        results = dataframes["results"]
        constructors = dataframes["constructors"]

        # Use dynamic column selection
        drivers = drivers[["driverId", "forename", "surname"]]
        races = races[["raceId", "year", races.columns[3]]]  
        results = results[["resultId", "raceId", "driverId", "constructorId", "position", "points"]]
        constructors = constructors[["constructorId", constructors.columns[-1]]]  

        # Merge datasets
        merged_data = results.merge(drivers, on="driverId").merge(races, on="raceId").merge(constructors, on="constructorId")
        merged_data.dropna(inplace=True)  # Handle missing values
        messagebox.showinfo("Preprocessing", "Data preprocessing process completed.")
        return merged_data
    except Exception as e:
        messagebox.showerror("Error", f"Data preprocessing failed: {e}")
        return None

# Function to inspect data structures
def inspect_data():
    details = ""
    for name, df in dataframes.items():
        details += f"Dataset: {name}\nColumns: {list(df.columns)}\nSample Data:\n{df.head(3)}\n{'-'*40}\n"
    display_details(details)

# Function to display details
def display_details(details):
    detail_window = tk.Toplevel()
    detail_window.title("Dataset Details")
    detail_window.geometry("800x600")
    
    text = tk.Text(detail_window, wrap=tk.WORD)
    text.insert(tk.END, details)
    text.pack(expand=True, fill=tk.BOTH)
    text.config(state=tk.DISABLED)

# Function to train KNN model
def train_knn_model(data):
    messagebox.showinfo("Training KNN", "KNN model training process started.")
    try:
        X = data[["year", "points"]]  # Features
        y = (data["position"] == 1).astype(int)  # Target: 1 if driver won, else 0

        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        knn = KNeighborsClassifier(n_neighbors=5)
        knn.fit(X_train, y_train)
        y_pred = knn.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)

        messagebox.showinfo("KNN Model", f"KNN Model Trained Successfully\nAccuracy: {accuracy:.2f}")
        plot_accuracy("KNN", accuracy)
        return knn
    except Exception as e:
        messagebox.showerror("Error", f"KNN model training failed: {e}")
        return None

# Function to train Decision Tree model
def train_decision_tree_model(data):
    messagebox.showinfo("Training Decision Tree", "Decision Tree model training process started.")
    try:
        X = data[["year", "points"]]
        y = (data["position"] == 1).astype(int)

        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        tree = DecisionTreeClassifier(max_depth=5, random_state=42)
        tree.fit(X_train, y_train)
        y_pred = tree.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)

        messagebox.showinfo("Decision Tree Model", f"Decision Tree Model Trained Successfully\nAccuracy: {accuracy:.2f}")
        plot_accuracy("Decision Tree", accuracy)
        return tree
    except Exception as e:
        messagebox.showerror("Error", f"Decision Tree model training failed: {e}")
        return None

# Function to plot accuracy
def plot_accuracy(model_name, accuracy):
    plt.figure()
    plt.bar(model_name, accuracy, color='blue')
    plt.ylim(0, 1)
    plt.title(f'Accuracy of {model_name} Model')
    plt.ylabel('Accuracy')
    plt.show()

# Function to preprocess data and train models
def preprocess_and_train_models():
    data = preprocess_data()
    if data is not None:
        knn_model = train_knn_model(data)
        decision_tree_model = train_decision_tree_model(data)
        messagebox.showinfo("Success", "Data preprocessing and model training completed.")

# Function to display data in a table format
def display_table(data):
    table_window = tk.Toplevel()
    table_window.title("Results")
    table_window.geometry("800x600")
    
    table = ttk.Treeview(table_window)
    table["columns"] = list(data.columns)
    table["show"] = "headings"

    for col in data.columns:
        table.heading(col, text=col)
        table.column(col, anchor="center")

    for _, row in data.iterrows():
        table.insert("", "end", values=row.tolist())

    table.pack(fill="both", expand=True)

# Function to display driver records
def display_driver_records():
    try:
        data = preprocess_data()
        if data is not None:
            top_drivers = data.groupby(["forename", "surname"]).agg({"points": "sum", "position": "count"}).sort_values(by="points", ascending=False).head(10)
            top_drivers.reset_index(inplace=True)
            display_table(top_drivers)
    except Exception as e:
        messagebox.showerror("Error", f"Failed to display driver records: {e}")

def display_team_constructor_records():
    try:
        data = preprocess_data()
        if data is not None:
            constructor_name_col = data.columns[-1]  
            team_points = data.groupby(constructor_name_col).agg({"points": "sum"}).sort_values(by="points", ascending=False).reset_index()
            team_points.columns = ['Constructor', 'Total Points']
            display_table(team_points.head(10))
    except Exception as e:
        messagebox.showerror("Error", f"Failed to display team/constructor records: {e}")

# Function to display Grand Prix Winners
def display_grand_prix_winners():
    try:
        data = preprocess_data()
        if data is not None:
            # Ensure position is treated as string for proper filtering
            data["position"] = data["position"].astype(str)
            
            winners = data[data["position"] == "1"].groupby(["year", "raceId"]).size().reset_index(name="Wins")
            winners = winners.sort_values(by="Wins", ascending=False).head(10)
            
            # Rename columns for better readability
            winners.columns = ['Year', 'Race ID', 'Wins']
            
            # Display the results in the table
            if not winners.empty:
                display_table(winners)
            else:
                messagebox.showinfo("No Data", "No Grand Prix winners found in the dataset.")
        else:
            raise ValueError("No data available after preprocessing.")
    except Exception as e:
        messagebox.showerror("Error", f"Failed to display Grand Prix winners: {e}")


# Function to display Lap Records
def display_lap_records():
    try:
        lap_times = dataframes["lap_times"]
        circuits = dataframes["circuits"]
        races = dataframes["races"]

        # Group by race and find the minimum lap time
        lap_records = lap_times.groupby("raceId").agg({"milliseconds": "min"}).reset_index()
        lap_records = lap_records.merge(races, on="raceId", how="left").merge(circuits, on="circuitId", how="left")

        lap_records = lap_records[["raceId", "year", "milliseconds"]].sort_values(by="milliseconds").head(10)
        lap_records.columns = ['Race ID', 'Year', 'Lap Time (ms)']  # Rename columns for clarity

        # Display top 10 lap records
        if not lap_records.empty:
            display_table(lap_records)
        else:
            messagebox.showinfo("No Data", "No Lap Records found in the dataset.")
    except Exception as e:
        messagebox.showerror("Error", f"Failed to display Lap Records: {e}")


def create_gui():
    root = tk.Tk()
    root.title("Formula 1 AI System")
    root.geometry("400x600")

    tk.Label(root, text="Formula 1 AI System", font=("Arial", 16)).pack(pady=20)
    tk.Button(root, text="Load Data", command=load_data, width=30).pack(pady=10)
    tk.Button(root, text="Validate Columns", command=validate_columns, width=30).pack(pady=10)
    tk.Button(root, text="Inspect Data", command=inspect_data, width=30).pack(pady=10)
    tk.Button(root, text="Preprocess Data and Train Models", command=preprocess_and_train_models, width=30).pack(pady=10)
    tk.Button(root, text="Driver Records", command=display_driver_records, width=30).pack(pady=10)
    tk.Button(root, text="Grand Prix Winners", command=display_grand_prix_winners, width=30).pack(pady=10)
    tk.Button(root, text="Lap Records", command=display_lap_records, width=30).pack(pady=10)
    tk.Button(root, text="Team/Constructor Records", command=display_team_constructor_records, width=30).pack(pady=10)
    
    root.mainloop()

if __name__ == "__main__":
    create_gui()